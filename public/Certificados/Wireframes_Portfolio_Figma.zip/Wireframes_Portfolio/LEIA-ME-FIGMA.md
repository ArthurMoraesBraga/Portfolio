# Wireframes — Portfólio Arthur Moraes

29 telas de baixa fidelidade: 14 estados em desktop (1200 px), 14 em mobile (390 px) e um menu mobile aberto. Base: portfolio(2).zip enviado em 15/10/2026.

## Importar no Figma
1. Extraia este ZIP.
2. Crie um arquivo de design vazio no Figma.
3. Arraste os arquivos SVG das pastas desktop e mobile para a área de trabalho. Importe SVG, não PNG, para manter formas e textos editáveis.
4. Cada SVG chega como um grupo; transforme o grupo em um Frame pelo menu de contexto (Frame selection). Confira os tamanhos: 1200 px no desktop e 390 px no mobile.
5. Para importar tudo de uma vez, use 00-Painel-completo.svg. Os grupos internos de cada tela devem ser separados e convertidos em Frames para prototipação.
6. Na aba Prototype, selecione a capa ou o botão, arraste o conector ao Frame de destino e configure On click → Navigate to.
7. Defina Início como ponto inicial do fluxo. A introdução pode usar After delay → Navigate to → Início.
8. Exporte as telas em PNG para o README, ou utilize os PNGs já incluídos.

## Ligações sugeridas
- Introdução → Início (após a animação).
- Cada capa do Início → página correspondente.
- AM / Início → Início; Faixas → menu mobile aberto.
- Sobre / Ver currículo → Prévia do currículo; Fechar → Sobre.
- Canvas / Turmas → Canvas Turmas; Atividades → Canvas Calendário.
- Ver atividades de uma matéria → calendário da matéria (os blocos representam o estado; não há consulta de dados no protótipo).
- GitHub / abas → Resumo, WakaTime, Atividade ou Horários.
- Anterior / Próxima seguem: Sobre, Projetos, Certificados, Músicas, Canvas, GitHub, Contato.
- Abrir PDF e links externos podem usar Open link com os endereços reais do projeto.

## Escopo e decisões
- As experiências estão dentro de Sobre mim, como no ZIP, e não foi inventada uma página de experiências.
- Turmas e Atividades são as duas abas do Canvas. Não foi acrescentado filtro ao calendário.
- O formulário prevê nome, e-mail, mensagem e resposta de envio.
- Números, datas e gráficos são ilustrativos: representam posições e hierarquia, não estatísticas reais.
- Linhas cinzas indicam texto; caixas com diagonais indicam imagens, documentos ou players.
- Não há cores finais, logos detalhadas ou fotografias: este material é de baixa fidelidade.
- A proposta documenta a versão do ZIP, sem afirmar que foi produzida antes do desenvolvimento.

## Atenção ao enunciado
O LAB01 solicita média fidelidade no Figma. Este pacote segue o pedido de baixa fidelidade do usuário. Para a entrega, evolua tipografia, espaçamentos, conteúdo e interações antes de considerar atendido o requisito.

## Arquivos
- desktop/: SVGs editáveis e PNGs de cada tela.
- mobile/: SVGs editáveis e PNGs de cada tela.
- 00-Painel-completo.svg: todos os grupos em uma prancha.
- Visao_geral_wireframes.png: visão geral desktop.

Este pacote não é um arquivo .fig nativo e não contém interações do Figma já configuradas.
